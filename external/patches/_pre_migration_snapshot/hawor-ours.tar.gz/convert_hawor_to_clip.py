"""把我们的 HaWoR 输出(world_space_res + SLAM) 转成 EgoInfinity 官方 retarget 的 clip 格式。
产出 <outdir>/{hand_joints.bin, hand_meta.json, scene.json}。双手(idx0左/idx1右),相机系,米制。
在 HaWoR/hawor_env 里跑(需 run_mano + load_slam_cam)。
用法: python convert_hawor_to_clip.py <hawor_example_dir> <NFR> <outdir> [fps]
"""
import warnings; warnings.filterwarnings("ignore")
import joblib, numpy as np, torch, os, sys, json
from hawor.utils.process import run_mano, run_mano_left
from lib.eval_utils.custom_utils import load_slam_cam
D=sys.argv[1]; NFR=int(sys.argv[2]); OUT=sys.argv[3]; FPS=float(sys.argv[4]) if len(sys.argv)>4 else 15.0
os.makedirs(OUT,exist_ok=True)
r=joblib.load(f"{D}/world_space_res.pth")
trans,rot,hpose,betas,valid=[torch.tensor(np.array(x)).float() for x in r]  # (2,T,·)
R_w2c,t_w2c,_,_=load_slam_cam(f"{D}/SLAM/hawor_slam_w_scale_0_{NFR}.npz")
R_w2c=R_w2c.numpy(); t_w2c=t_w2c.numpy()
T=trans.shape[1]
J=np.full((T,2,21,3),np.nan,dtype=np.float32)   # (T, max_h=2, 21, 3)  idx0=left idx1=right
for hi,runner in [(0,run_mano_left),(1,run_mano)]:
    out=runner(trans[hi:hi+1].cuda(),rot[hi:hi+1].cuda(),hpose[hi:hi+1].cuda(),betas=betas[hi:hi+1].cuda())
    Jw=out["joints"][0].cpu().numpy()            # (T,21,3) world
    Jc=np.einsum("tij,tkj->tki",R_w2c,Jw)+t_w2c[:,None,:]  # 相机系
    v=valid[hi].cpu().numpy().astype(bool) & np.isfinite(Jc).all(axis=(1,2))
    J[v,hi]=Jc[v]
J.tofile(f"{OUT}/hand_joints.bin")
meta={"n_frames":int(T),"max_hands":2,"joints_shape":[int(T),2,21,3],
      "is_right_per_frame":[[False,True] for _ in range(T)]}
json.dump(meta,open(f"{OUT}/hand_meta.json","w"),indent=1)
# scene: focal 用 HaWoR est_focal; gravity 名义值(相机y向下->up≈[0,-1,0]); fps
foc=600.0
ef=f"{D}/est_focal.txt"
if os.path.exists(ef):
    try: foc=float(open(ef).read().split()[0])
    except: pass
scene={"camera":{"focal":foc,"gravity_up":[0.0,-1.0,0.0]},"fps":FPS,"id":os.path.basename(OUT)}
json.dump(scene,open(f"{OUT}/scene.json","w"),indent=1)
vr=int((np.isfinite(J[:,1,0,0])).sum()); vl=int((np.isfinite(J[:,0,0,0])).sum())
print(f"{OUT}: T={T} focal={foc} 右手有效{vr}/{T} 左手有效{vl}/{T}")
